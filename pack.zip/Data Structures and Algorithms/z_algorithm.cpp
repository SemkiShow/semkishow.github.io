#include <bits/stdc++.h>
using namespace std;

void get_z(const string& input, vector<int>& z)
{
    int n = input.size();
    z.resize(n, 0);
    int l = 0, r = 0;
    for (int i = 1; i < n; i++)
    {
        z[i] = max(0, min(z[i - l], r - i + 1));
        while (i + z[i] < n && input[z[i]] == input[z[i] + i])
        {
            l = i;
            r = i + z[i];
            z[i]++;
        }
    }
}
