#include <bits/stdc++.h>
using namespace std;

struct SegmentTree
{
    vector<long long> tree;
    vector<long long> lazy;
    size_t size = 0;

    SegmentTree(size_t n)
    {
        size = n;
        tree.resize(4 * n);
        lazy.resize(4 * n);
    }

    void build(vector<int>& a, int v, int tl, int tr)
    {
        if (tl == tr)
        {
            tree[v] = a[tl];
        }
        else
        {
            int tm = (tl + tr) / 2;
            build(a, 2 * v, tl, tm);
            build(a, 2 * v + 1, tm + 1, tr);
            tree[v] = tree[2 * v] + tree[2 * v + 1];
        }
    }

    void push(int v, int tl, int tr)
    {
        if (lazy[v] != 0)
        {
            tree[v] = lazy[v];
            if (tl != tr)
            {
                lazy[2 * v] = lazy[v];
                lazy[2 * v + 1] = lazy[v];
            }
            lazy[v] = 0;
        }
    }

    void range_update(int v, int tl, int tr, int l, int r, int val)
    {
        push(v, tl, tr);
        if (l > r) return;
        if (l <= tl && tr <= r)
        {
            lazy[v] = val;
            push(v, tl, tr);
        }
        else
        {
            int tm = (tl + tr) / 2;
            range_update(2 * v, tl, tm, l, r, val);
            range_update(2 * v + 1, tm + 1, tr, l, r, val);
        }
    }

    void point_update(int v, int tl, int tr, int pos, int val)
    {
        range_update(v, tl, tr, pos, pos, val);
    }

    long long range_query(int v, int tl, int tr, int l, int r)
    {
        push(v, tl, tr);
        if (l > r) return 0;
        if (l == tl && r == tr) return tree[v];
        int tm = (tl + tr) / 2;
        return range_query(2 * v, tl, tm, l, min(r, tm)) +
               range_query(2 * v + 1, tm + 1, tr, max(l, tm + 1), r);
    }

    long long point_query(int v, int tl, int tr, int pos)
    {
        return range_query(v, tl, tr, pos, pos);
    }
};
