#include <bits/stdc++.h>
using namespace std;

bool* solve(long long n)
{
    bool* primes = new bool[n];
    for (size_t i = 0; i < n; i++)
    {
        primes[i] = true;
    }
    primes[0] = false;
    primes[1] = false;
    for (size_t i = 0; i * i <= n; i++)
    {
        size_t j = 2 * i;
        while (j <= n)
        {
            primes[j] = false;
            j += i;
        }
    }
    return primes;
}
