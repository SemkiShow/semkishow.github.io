#include <bits/stdc++.h>
using namespace std;

struct Node
{
    vector<int> neighbours;
};

struct SegmentTree
{
    vector<int> best, sum;

    SegmentTree(int size)
    {
        best.resize(4 * size, INT_MIN);
        sum.resize(4 * size, 0);
    }

    void build(const vector<int>& count, const vector<int>& dist, int v, int tl, int tr)
    {
        if (tl == tr)
        {
            int c = count[tl];
            sum[v] = c;
            if (c > 0)
                best[v] = dist[tl] + c - 1;
            else
                best[v] = INT_MIN;
        }
        else
        {
            int tm = (tl + tr) / 2;
            build(count, dist, 2 * v, tl, tm);
            build(count, dist, 2 * v + 1, tm + 1, tr);
            sum[v] = sum[2 * v] + sum[2 * v + 1];
            best[v] = max(best[2 * v + 1], best[2 * v] + sum[2 * v + 1]);
        }
    }

    void update(int v, int tl, int tr, int val, int pos, int dist)
    {
        if (tl == tr)
        {
            sum[v] = val;
            if (val > 0)
                best[v] = dist + val - 1;
            else
                best[v] = INT_MIN;
            return;
        }
        int tm = (tl + tr) / 2;
        if (pos <= tm)
            update(2 * v, tl, tm, val, pos, dist);
        else
            update(2 * v + 1, tm + 1, tr, val, pos, dist);
        sum[v] = sum[2 * v] + sum[2 * v + 1];
        best[v] = max(best[2 * v + 1], best[2 * v] + sum[2 * v + 1]);
    }

    int get_best() { return best[1]; }
};

int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    size_t n, m;
    cin >> n >> m;
    vector<string> a(n);
    for (size_t i = 0; i < n; i++)
    {
        cin >> a[i];
    }

    vector<Node> nodes(n * n);
    int start = -1;
    for (size_t i = 0; i < n; i++)
    {
        for (size_t j = 0; j < n; j++)
        {
            if (i > 0 && a[i - 1][j] != '#') nodes[i * n + j].neighbours.push_back((i - 1) * n + j);
            if (i < n - 1 && a[i + 1][j] != '#')
                nodes[i * n + j].neighbours.push_back((i + 1) * n + j);
            if (j > 0 && a[i][j - 1] != '#') nodes[i * n + j].neighbours.push_back(i * n + j - 1);
            if (j < n - 1 && a[i][j + 1] != '#')
                nodes[i * n + j].neighbours.push_back(i * n + j + 1);
            if (a[i][j] == 'Z') start = i * n + j;
        }
    }

    queue<int> q;
    vector<char> visited(n * n, false);
    vector<int> dist(n * n, INT_MAX);
    int max_dist = 0;
    q.push(start);
    visited[start] = true;
    dist[start] = 0;
    while (!q.empty())
    {
        for (auto& node: nodes[q.front()].neighbours)
        {
            if (visited[node]) continue;
            visited[node] = true;
            dist[node] = dist[q.front()] + 1;
            max_dist = max(max_dist, dist[node]);
            q.push(node);
        }
        q.pop();
    }

    vector<int> count(max_dist + 1, 0);
    for (size_t i = 0; i < n; i++)
    {
        for (size_t j = 0; j < n; j++)
        {
            if (a[i][j] == 'F')
            {
                count[dist[i * n + j]]++;
            }
        }
    }

    SegmentTree tree(max_dist + 1);
    vector<int> inc(max_dist + 1);
    for (size_t i = 0; i < inc.size(); i++)
    {
        inc[i] = i;
    }
    tree.build(count, inc, 1, 0, max_dist);

    for (size_t i = 0; i <= m; i++)
    {
        cout << max(0, tree.get_best()) << '\n';

        if (i < m)
        {
            int x, y;
            cin >> y >> x;
            x--;
            y--;
            int d = dist[y * n + x];
            if (a[y][x] == 'F')
            {
                a[y][x] = '.';
                count[d]--;
            }
            else
            {
                a[y][x] = 'F';
                count[d]++;
            }
            tree.update(1, 0, max_dist, count[d], d, d);
        }
    }
}
