#include <bits/stdc++.h>
using namespace std;

struct SegmentTree
{
    vector<long long> tree;
    size_t size = 0;

    SegmentTree(size_t n)
    {
        size = n;
        tree.resize(4 * n);
    }

    void build(vector<int>& a, int v, int tl, int tr)
    {
        if (tl == tr)
        {
            tree[v] = a[tl];
        }
        else
        {
            int tm = (tl + tr) / 2;
            build(a, 2 * v, tl, tm);
            build(a, 2 * v + 1, tm + 1, tr);
            tree[v] = tree[2 * v] + tree[2 * v + 1];
        }
    }

    void range_update(int v, int tl, int tr, int l, int r, int val)
    {
        if (l > r) return;
        if (tl == tr)
        {
            tree[v] = (tr - tl + 1) * val;
        }
        else
        {
            int tm = (tl + tr) / 2;
            range_update(2 * v, tl, tm, l, r, val);
            range_update(2 * v + 1, tm + 1, tr, l, r, val);
            tree[v] = tree[2 * v] + tree[2 * v + 1];
        }
    }

    void point_update(int v, int tl, int tr, int pos, int val)
    {
        range_update(v, tl, tr, pos, pos, val);
    }

    long long range_query(int v, int tl, int tr, int l, int r)
    {
        if (l > r) return 0;
        if (l == tl && r == tr) return tree[v];
        int tm = (tl + tr) / 2;
        return range_query(2 * v, tl, tm, l, min(r, tm)) +
               range_query(2 * v + 1, tm + 1, tr, max(l, tm + 1), r);
    }

    long long point_query(int v, int tl, int tr, int pos)
    {
        return range_query(v, tl, tr, pos, pos);
    }
};
