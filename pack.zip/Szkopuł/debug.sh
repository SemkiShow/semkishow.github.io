#!/bin/bash

set -euo pipefail

if [ -z "${1+x}" ]; then
    echo "You must provide an input target!"
    exit 1
fi

if [ "$1" == "-h" ] || [ "$1" == "--help" ]; then
    echo "Usage: ./debug.sh <task_name> [test_name]"
    echo ""
    echo "[test_name]    The test used for running the task"
    echo "               The default value is 0"
    exit 0
fi

test=0
if [ ! -z ${2+x} ]; then
    test=$2
fi

g++ -o bin/$1 src/$1.cpp -O0 -g
set +e
./bin/$1 < tests/$1/$test.in > /dev/null
exit_code=$?
set -e
if [ $exit_code -eq 0 ]; then
    echo -e "\x1b[32mNo crashes detected!\x1b[0m"
else
    coredumpctl dump > core.dump
    gdb ./bin/$1 core.dump
fi
