#!/bin/bash

set -euo pipefail

if [ -z "${1+x}" ]; then
    echo "You must provide an input target!"
    exit 1
fi
if [ -z "${2+x}" ]; then
    echo "You must provide tests number!"
    exit 1
fi

if [ "$1" == "-h" ] || [ "$1" == "--help" ]; then
    echo "Usage: ./new_task.sh <task_name> <tests_number> [editor]"
    echo ""
    echo "[editor]    The editor used to open the created <task_name>.cpp and tests"
    echo "            The default value is codium"
    exit 0
fi

editor=codium
if [ ! -z "${3+x}" ]; then
    editor="$3"
fi

suffix=1
task_name=$1
while [ -f src/$task_name.cpp ]; do
    ((suffix++))
    task_name=$1$suffix
done

cp sample.cpp src/$task_name.cpp
mkdir -p tests/$task_name
for i in $(seq 0 $(($2 - 1))); do
    touch tests/$task_name/$i.in
    $editor tests/$task_name/$i.in
    touch tests/$task_name/$i.out
    $editor tests/$task_name/$i.out
done
$editor src/$task_name.cpp
