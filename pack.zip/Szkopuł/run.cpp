#include <algorithm>
#include <atomic>
#include <filesystem>
#include <fstream>
#include <future>
#include <iostream>
#include <mutex>
#include <numeric>
#include <thread>
#include <unistd.h>
#include <vector>
namespace fs = std::filesystem;

#ifdef _WIN32
#include <windows.h>
#else
#include <fcntl.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#endif

#define RED "\x1b[31m"
#define GREEN "\x1b[32m"
#define YELLOW "\x1b[33m"
#define RESET "\x1b[0m"

#define CXX "g++"
#define CXXFLAGS "-Wall -Wextra -O2 -g -std=c++17"

const size_t threadsNumber = std::max(1u, std::thread::hardware_concurrency());
std::mutex mtx;

std::atomic<bool> interrupted(false);

#ifdef _WIN32
int RunCommand(const std::string& cmd)
{
    STARTUPINFOA si{};
    PROCESS_INFORMATION pi{};
    si.cb = sizeof(si);
    std::string fullCmd = "cmd /C \"" + cmd + "\"";
    if (!CreateProcessA(nullptr, fullCmd.data(), nullptr, nullptr, FALSE, 0, nullptr, nullptr, &si,
                        &pi))
    {
        std::cerr << "Failed to start process\n";
        return -1;
    }
    while (true)
    {
        DWORD result = WaitForSingleObject(pi.hProcess, 50);
        if (result != WAIT_TIMEOUT) break;
        if (interrupted.load())
        {
            TerminateProcess(pi.hProcess, 130);
            CloseHandle(pi.hProcess);
            CloseHandle(pi.hThread);
            return 130;
        }
    }
    DWORD exitCode;
    GetExitCodeProcess(pi.hProcess, &exitCode);
    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);
    return static_cast<int>(exitCode);
}
#else
int RunCommand(const std::string& cmd)
{
    pid_t pid = fork();
    if (pid < 0) return -1;
    if (pid == 0)
    {
        execl("/bin/sh", "sh", "-c", cmd.c_str(), nullptr);
        _exit(127);
    }

    int status = 0;
    while (true)
    {
        pid_t result = waitpid(pid, &status, WNOHANG);
        if (result == pid) break;
        if (interrupted.load())
        {
            kill(pid, SIGKILL);
            return 130;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
    }

    if (WIFEXITED(status)) return WEXITSTATUS(status);
    return -1;
}
#endif

int RunCommandWithTimeout(const std::string& command, int timeout)
{
    auto fut = std::async(std::launch::async, [&]() { return RunCommand(command); });

    if (fut.wait_for(std::chrono::seconds(timeout)) == std::future_status::ready)
    {
        return fut.get();
    }
    else
    {
        return 124;
    }
}

void Compile(const std::string& fileName)
{
    std::string compileCommand =
        std::string(CXX) + " " + CXXFLAGS + " -o bin/" + fileName + " src/" + fileName + ".cpp";
    std::cout << compileCommand << '\n';
    if (RunCommand(compileCommand) != 0)
    {
        std::cout << RED << "Failed to compile " << fileName << "!" << RESET << '\n';
        exit(1);
    }
}

std::string Trim(const std::string& s)
{
    size_t end = s.find_last_not_of(" \t\r\n");
    return (end == std::string::npos ? "" : s.substr(0, end + 1));
}

bool FilesEqual(const fs::path& a, const fs::path& b)
{
    std::ifstream fa(a), fb(b);
    if (!fa || !fb) return false;
    std::string la, lb;
    while (true)
    {
        bool ra = bool(getline(fa, la)), rb = bool(getline(fb, lb));
        if (!ra && !rb) return true;
        if (ra != rb) return false;
        if (Trim(la) != Trim(lb)) return false;
    }
}

void PrintDiff(const fs::path& a, const fs::path& b)
{
    std::ifstream fa(a), fb(b);
    std::string la, lb;
    while (true)
    {
        bool ra = bool(getline(fa, la)), rb = bool(getline(fb, lb));
        if (!ra && !rb) break;
        if (Trim(la) != Trim(lb))
        {
            std::cout << "- " << Trim(la) << '\n';
            std::cout << "+ " << Trim(lb) << '\n';
        }
    }
}

std::string GetRunCommand(const std::string& bin, const fs::path& inFile, const fs::path& outFile)
{
    return bin + " < " + inFile.string() + " > " + outFile.string();
}

std::vector<size_t> total(threadsNumber), passed(threadsNumber);

void RunThread(size_t threadId, const std::vector<fs::path>& inputs, const fs::path& testDir,
               const std::string& task, const std::string& checkBin, const std::string& binary,
               double timeout, bool showPassed, bool showInput, bool showDiff)
{
    for (size_t i = threadId; i < inputs.size(); i += threadsNumber)
    {
        std::string name = inputs[i].stem().string();
        fs::path expected = testDir / (name + ".out"), tmpOut = "tmp/" + task + "_" + name + ".out";
        if (!fs::exists(expected) && checkBin.empty())
        {
            std::lock_guard<std::mutex> lock(mtx);
            std::cout << YELLOW << "NOTEST " << name << RESET << '\n';
            continue;
        }
        total[threadId]++;

        int rc = RunCommandWithTimeout(GetRunCommand(binary, inputs[i], tmpOut), timeout);
        if (rc == 124 || rc == 137)
        {
            std::lock_guard<std::mutex> lock(mtx);
            std::cout << RED << "TIMEOUT " << name << RESET << '\n';
            continue;
        }
        if (rc != 0)
        {
            std::lock_guard<std::mutex> lock(mtx);
            std::cout << RED << "CRASH " << name << RESET << '\n';
            continue;
        }

        bool ok = false;
        if (!checkBin.empty())
        {
            std::string checkCmd = checkBin + " " + inputs[i].string() + " " + tmpOut.string();
            ok = (RunCommand(checkCmd) == 0);
        }
        else
        {
            ok = FilesEqual(expected, tmpOut);
        }

        if (ok)
        {
            std::lock_guard<std::mutex> lock(mtx);
            std::cout << GREEN << "PASS " << name << RESET << (showPassed ? '\n' : '\r');
            if (!showPassed) std::cout << std::flush;
            passed[threadId]++;
        }
        else
        {
            std::lock_guard<std::mutex> lock(mtx);
            std::cout << RED << "FAIL " << name << RESET << '\n';
            if (showInput)
            {
                std::ifstream fin(inputs[i]);
                std::cout << std::string((std::istreambuf_iterator<char>(fin)),
                                         std::istreambuf_iterator<char>());
            }
            if (showDiff) PrintDiff(expected, tmpOut);
        }
    }
}

int main(int argc, char** argv)
{
    if (argc < 2)
    {
        std::cout << "Usage: run <task> [timeout] [--show-diff] [--show-input] [--show-passed]\n";
        return 1;
    }

#ifdef _WIN32
    std::system("");
#endif

    std::string task = argv[1];
    double timeout = (argc > 2 && isdigit(argv[2][0])) ? std::stod(argv[2]) : 3.0;
    bool showDiff = false, showInput = false, showPassed = false;
    for (int i = 2; i < argc; i++)
    {
        std::string f = argv[i];
        if (f == "--show-diff") showDiff = true;
        if (f == "--show-input") showInput = true;
        if (f == "--show-passed") showPassed = true;
    }

    if (!fs::exists("bin")) fs::create_directory("bin");
    if (!fs::exists("tmp")) fs::create_directory("tmp");

    fs::path testDir = "tests/" + task;
    if (!fs::exists(testDir))
    {
        // _slow
        testDir = "tests/" + task.substr(0, task.size() - 5);
    }

    std::string binary = "./bin/" + task;
#ifdef _WIN32
    binary += ".exe";
#endif
    binary = fs::absolute(binary).string();
    Compile(task);
    std::string checkBin = "";
    if (fs::exists("src/" + task + "_check.cpp"))
    {
        Compile(task + "_check");
        checkBin = "./bin/" + task + "_check";
#ifdef _WIN32
        checkBin += ".exe";
#endif
        checkBin = fs::absolute(checkBin).string();
    }

    std::vector<fs::path> inputs;
    for (auto& p: fs::directory_iterator(testDir))
        if (p.path().extension() == ".in") inputs.push_back(p.path());
    if (inputs.empty())
    {
        std::cout << "NOTESTS tests/" << testDir << '\n';
        return 0;
    }

    std::thread threads[threadsNumber];
    for (size_t i = 0; i < threadsNumber; i++)
    {
        threads[i] = std::thread(RunThread, i, inputs, testDir, task, checkBin, binary, timeout,
                                 showPassed, showInput, showDiff);
    }
    for (size_t i = 0; i < threadsNumber; i++)
    {
        threads[i].join();
    }

    size_t totalCount = std::accumulate(total.begin(), total.end(), 0);
    size_t passedCount = std::accumulate(passed.begin(), passed.end(), 0);
    std::cout << (passed == total ? GREEN : RED) << "Passed " << passedCount << "/" << totalCount
              << " tests" << RESET << '\n';
}
