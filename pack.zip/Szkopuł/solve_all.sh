#!/bin/bash

set -euo pipefail
max_jobs=$(nproc)

if [ -z "${1+x}" ]; then
    echo "You must provide an input target!"
    exit 1
fi

if [ "$1" == "-h" ] || [ "$1" == "--help" ]; then
    echo "Usage: ./solve_all.sh <task_name> [-f]"
    echo ""
    echo "-f, --force    Force solve all problems"
    exit 0
fi

make $1_slow || (make $1 && mv bin/$1 bin/$1_slow)
test_dir="$1"
if [ ! -d tests/$1 ]; then
    test_dir=$(basename "$1" _slow)
fi

count=0
for test in tests/$test_dir/*.in; do
    {
        name=$(basename "$test" .in)
        if [ -f "tests/$test_dir/$name.out" ] && [ -z "$2" ]; then
            exit 0
        fi
        echo "Solving test $name..."
        ./bin/$1_slow < "tests/$test_dir/$name.in" > "tests/$test_dir/$name.out"
    } &
    (( ++count >= max_jobs )) && { wait -n; ((count--)); }
done
