#include <bits/stdc++.h>
using namespace std;

bool check() { return true; }

int main(int argc, char* argv[])
{
    if (argc != 3)
    {
        printf("Usage: %s <input_path> <program_output_path>\n", argv[0]);
        return 1;
    }
    ios::sync_with_stdio(0);
    cin.tie(0);
    ifstream in(argv[1]);
    ifstream out(argv[2]);
    string correct_out_path = string(argv[1]).substr(0, strlen(argv[1]) - 3) + ".out";
    if (!std::filesystem::exists(correct_out_path)) return 1;
    ifstream correct_out(correct_out_path);

    return !check();
}
