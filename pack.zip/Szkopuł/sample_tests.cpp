#include <bits/stdc++.h>
using namespace std;

int main()
{
    srand(0);
    for (size_t i = 0; i < 1000; i++)
    {
        ofstream test_file("tests/TEST_DIR/my_" + to_string(i) + ".in");
        // Easy tests
        size_t tests_number = rand() % (int)1e2 + 1;
        // Medium tests
        if (i > 300) tests_number = rand() % (int)1e4 + 1;
        // Hard tests
        if (i > 900) tests_number = rand() % (int)1e5 + 1;
        test_file << tests_number << '\n';

        test_file.close();
    }
}
