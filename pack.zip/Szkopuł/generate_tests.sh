#!/bin/bash

set -euo pipefail

if [ -z "${1+x}" ]; then
    echo "You must provide an input target!"
    exit 1
fi

if [ "$1" == "-h" ] || [ "$1" == "--help" ]; then
    echo "Usage: ./generate_tests.sh <task_name>"
    echo ""
    echo "Compile and run src/<task_name>_tests.cpp and solve the generated tests"
    echo "using src/<task_name>_slow.cpp or src/<task_name>.cpp, if"
    echo "src/<task_name>_tests.cpp doesn't exist"
    exit 0
fi

find tests/$1 -name "my_*" -delete
make $1_tests
echo "Generating tests..."
./bin/$1_tests
./solve_all.sh $1
