#!/bin/bash

set -euo pipefail
trap "kill 0; exit 1" SIGINT
timeout="3s"
show_passed=false
show_input=false
show_diff=false
max_jobs=$(nproc)

if [ -z "${1+x}" ]; then
    echo "You must provide an input target!"
    exit 1
fi

if [ "$1" == "-h" ] || [ "$1" == "--help" ]; then
    echo "Usage: ./run.sh <task_name> [timeout]"
    echo ""
    echo "[timeout]    The timeout used for running the task"
    echo "             The default value is $timeout"
    exit 0
fi
if [ ! -z "${2+x}" ]; then
    timeout="$2"
fi

mkdir -p bin tmp

test_dir="$1"
if [ ! -d tests/$1 ]; then
    test_dir=$(basename "$1" _slow)
fi

make $1
if [ -f src/${test_dir}_check.cpp ]; then
    make ${test_dir}_check
fi

set +eo pipefail
if ! find tests/$test_dir -name "*.in" | grep -q .; then
    echo "No tests found in tests/$test_dir"
    exit 0
fi
set -o pipefail

count=0
{
    for test in tests/$test_dir/*.in; do
        {
            name=$(basename "$test" .in)
            if [ ! -f "tests/$test_dir/$name.out" ] && [ ! -f src/${test_dir}_check.cpp ]; then
                echo "NOTEST $name"
                exit 1
            fi
            timeout $timeout bash -c "./bin/$1 < tests/$test_dir/$name.in > tmp/$1$name.out"
            exit_code=$?
            if [ $exit_code -eq 124 ] || [ $exit_code -eq 137 ]; then
                echo "TIMEOUT $name"
                exit 1
            elif [ $exit_code -ne 0 ]; then
                echo "CRASH $name"
                exit 1
            fi
            if [ -f src/${test_dir}_check.cpp ]; then
                if ./bin/${test_dir}_check "tests/$test_dir/$name.in" "tmp/$1$name.out" >/dev/null; then
                    echo "PASS $name"
                else
                    echo "FAIL $name"
                fi
            else
                if diff -Z "tests/$test_dir/$name.out" "tmp/$1$name.out" >/dev/null; then
                    echo "PASS $name"
                else
                    echo "FAIL $name"
                fi
            fi
        } &
        (( ++count >= max_jobs )) && { wait -n; ((count--)); }
    done
    wait
} | {
    passed=0
    total=0
    while read -r status name; do
        ((total++))
        case "$status" in
        NOTEST)
            echo -e "\x1b[33mSkipping test $name, because there is no output file!\x1b[0m"
            ((total--))
            ;;
        PASS)
            ((passed++))
            if $show_passed; then
                echo -e "\x1b[32mTest $name passed!\x1b[0m"
            else
                printf "\x1b[32mTest $name passed!\x1b[0m\r"
            fi
            ;;
        FAIL)
            echo -e "\x1b[31mTest $name failed!\x1b[0m"
            if [ -f "tests/$test_dir/$name.out" ] && [ -f "tmp/$1$name.out" ]; then
                if $show_input; then
                    cat tests/$test_dir/$name.in
                fi
                if $show_diff; then
                    diff -Z "tests/$test_dir/$name.out" "tmp/$1$name.out"
                fi
            fi
            ;;
        TIMEOUT)
            echo -e "\x1b[31mTest $name timed out!\x1b[0m"
            ;;
        CRASH)
            echo -e "\x1b[31mTest $name crashed!\x1b[0m"
            ;;
        esac
    done

    if [ "$passed" -eq "$total" ]; then
        echo -e "\x1b[32mPassed $passed/$total tests\x1b[0m"
    else
        echo -e "\x1b[31mPassed $passed/$total tests\x1b[0m"
    fi
}
